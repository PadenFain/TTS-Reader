﻿This is a basic demonstration of a winforms TTS reader. Functionality is currently very limited.

To use, simply run the TTS Reader.exe, click on "Select File", navigate to your text file (only supports .txt at this time), and click "Read".

There is no pause functionality, Stopping and Starting returns the reader to the beginning of the file.